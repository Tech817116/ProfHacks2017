/**
 * 
 */
package main;

/**
 * @author MLH
 *
 */
public class Motion 
{

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		

	}

}
