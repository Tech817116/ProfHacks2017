/**
 * 
 */
package main;

import com.leapmotion.leap.Controller;
import com.leapmotion.leap.Listener;

import javafx.application.Application;
import javafx.stage.Stage;

public class LeapConcepts extends Application {
    Controller c;
    Listener l;

    public void start (Stage stage) {
         // set up the scene and stage
        c = new Controller();
        l = new Listener();
        c.addListener (l);
    }
}